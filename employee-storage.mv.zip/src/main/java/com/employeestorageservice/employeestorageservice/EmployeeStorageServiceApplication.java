package com.employeestorageservice.employeestorageservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeStorageServiceApplication {
	public static void main(String[] args) {
		SpringApplication.run(EmployeeStorageServiceApplication.class, args);
	}

}
