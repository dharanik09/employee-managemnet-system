package com.employeestorageservice.employeestorageservice.mapper;

import org.springframework.stereotype.Component;

@Component
public class Test2 implements  CommandLineRunner{
    @Override
    public void run(String... args) throws Exception {
        System.out.println("Test2");
    }
}
