package com.employeestorageservice.employeestorageservice.mapper;

public interface CommandLineRunner {

    void run(String... args) throws Exception;
}
